package com.proyecto.mx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaV2Application {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaV2Application.class, args);
	}

}
