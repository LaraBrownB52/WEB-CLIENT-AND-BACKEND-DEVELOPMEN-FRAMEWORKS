package com.proyecto.mx.modelo.dao;

import org.springframework.data.repository.CrudRepository;

import com.proyecto.mx.modelo.entidades.Prestamo;

public interface PrestamoDAO extends CrudRepository<Prestamo, Long>  {

}
