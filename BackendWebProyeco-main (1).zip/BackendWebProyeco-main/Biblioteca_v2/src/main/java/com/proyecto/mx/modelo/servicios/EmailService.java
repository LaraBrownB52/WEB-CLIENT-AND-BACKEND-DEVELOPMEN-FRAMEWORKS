package com.proyecto.mx.modelo.servicios;

public interface EmailService {
	
	void sendSimpleMessage(String to, String subject, String text);

   
}
