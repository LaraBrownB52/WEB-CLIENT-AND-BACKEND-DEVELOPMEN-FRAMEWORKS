package com.proyecto.mx.modelo.dao;

import org.springframework.data.repository.CrudRepository;

import com.proyecto.mx.modelo.entidades.Autor;


public interface AutorDAO extends CrudRepository<Autor, Long> {

}
